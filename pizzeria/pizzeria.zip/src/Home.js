import { Component } from "react";

import Home3 from './images/Home3.png';

class Home extends Component{

    render(){

        return(

            <div>
                <img src={Home3}/>
                

            </div>

        )

    }

}

export default Home;